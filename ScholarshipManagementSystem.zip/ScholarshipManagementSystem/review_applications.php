<?php
session_start();
require_once 'db_config.php';

if (!isset($_SESSION['member_id'])) {
    header("Location: index.php");
    exit;
}

// Modified SQL query to fetch both Pending and Approved applications
$sql = "SELECT a.Application_ID, a.Date_Applied, a.Documents, s.Student_Name, s.GPA, s.Parents_Monthly_Income, sc.Scholarship_Name, a.Status
        FROM applications a
        JOIN students s ON a.Student_ID = s.Student_ID
        JOIN scholarships sc ON a.Scholarship_ID = sc.Scholarship_ID
        WHERE a.Status IN ('Pending', 'Approved')";  // Fetch both Pending and Approved applications
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Review Applications</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
    <div class="container mt-5">
        <div class="card shadow p-4">
            <h3 class="mb-4">📥 Review Applications</h3>
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>App ID</th>
                        <th>Student</th>
                        <th>Scholarship</th>
                        <th>GPA</th>
                        <th>Income</th>
                        <th>Date</th>
                        <th>Documents</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                <?php while ($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?= $row['Application_ID'] ?></td>
                        <td><?= $row['Student_Name'] ?></td>
                        <td><?= $row['Scholarship_Name'] ?></td>
                        <td><?= $row['GPA'] ?></td>
                        <td>Rs. <?= number_format($row['Parents_Monthly_Income']) ?></td>
                        <td><?= $row['Date_Applied'] ?></td>
                        <td>
                            <?php if ($row['Documents']): ?>
                                <!-- Display a link to view the document if it's available -->
                                <a href="view_document.php?file=<?= urlencode($row['Documents']) ?>" target="_blank" class="btn btn-sm btn-info">View Document</a>
                            <?php else: ?>
                                No Document
                            <?php endif; ?>
                        </td>
                        <td><?= $row['Status'] ?></td>  <!-- Added the Status column -->
                        <td>
                            <?php if ($row['Status'] == 'Pending'): ?>
                                <a href="award_points.php?id=<?= $row['Application_ID'] ?>" class="btn btn-sm btn-success">Review</a>
                            <?php else: ?>
                                <button class="btn btn-sm btn-secondary" disabled>Reviewed</button> <!-- Disabled button for approved applications -->
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endwhile; ?>
                </tbody>
            </table>
            <a href="committee_dashboard.php" class="btn btn-secondary mt-3">⬅ Back to Dashboard</a>
        </div>
    </div>
</body>
</html>
