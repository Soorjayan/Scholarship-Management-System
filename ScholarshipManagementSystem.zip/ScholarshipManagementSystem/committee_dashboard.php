<?php  
session_start();  
require_once 'db_config.php'; // ✅ Connect to the database if needed  

if (!isset($_SESSION['member_id'])) {  
    header("Location: index.php");  
    exit;  
}  
?>  
<!DOCTYPE html>  
<html>  
<head>  
    <title>Committee Dashboard</title>  
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">  
</head>  
<body class="bg-light">  
    <div class="container mt-5">  
        <div class="card shadow p-4">  
            <h2 class="mb-4">Welcome, <?php echo $_SESSION['name']; ?> 🧑‍💼</h2>  
            <ul class="list-group">  
                <li class="list-group-item">  
                    <a href="committee_profile.php">👤 View Profile</a>  
                </li>  
                <li class="list-group-item">  
                    <a href="review_applications.php">📥 Review Applications</a>  
                </li>  
                <li class="list-group-item">  
                    <a href="disburse_funds.php">💸 Disburse Funds</a>  
                </li>  
                <li class="list-group-item">  
                    <a href="update_payment.php">📝 Payment Records</a>  
                </li>  
                <li class="list-group-item">  
                    <a href="add_scholarship.php">➕ Add Scholarship</a>  
                </li>  
                <li class="list-group-item">  
                    <a href="index.php" class="text-danger">🔓 Logout</a>  
                </li>  
            </ul>  
        </div>  
    </div>  
</body>  
</html>  
