<?php  
session_start();  
require_once 'db_config.php'; // ✅ Connect to the database if needed  

if (!isset($_SESSION['member_id'])) {  
    header("Location: index.php");  
    exit;  
}  
?>

<!DOCTYPE html>  
<html>  
<head>  
    <title>Committee Dashboard</title>  
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">  
    <style>  
        /* Custom Styling */
        .header {  
            text-align: center;  
            background-color: #007BFF;  
            color: white;  
            padding: 20px;  
            position: relative;  
        }  
        .header h1 {  
            margin: 0;  
            font-size: 36px;  
        }  
        .header h2 {  
            margin-top: 10px;  
            font-size: 24px;  
        }  
        .header .logout-btn {  
            position: absolute;  
            top: 35px; /* 0.5 cm down */  
            right: 40px;  
            background-color: #66b0ff; /* Light blue color for logout button */  
            color: white;  
            padding: 12px 20px;  
            border-radius: 5px;  
            text-decoration: none; /* Remove underline from the logout button */  
            font-size: 16px; /* Increase the size of the button */  
        }  
        .box-container {  
            background-color: #E6E6FA; /* Light purple color for the big box */  
            padding: 30px;  
            border-radius: 10px;  
            margin-top: 30px;  
        }  
        .card-container {  
            display: flex;  
            justify-content: center;  
            gap: 50px; /* Increase the space between boxes */  
            margin-top: 50px; /* Increase space above the boxes */  
        }  
        .card-container .card {  
            width: 280px; /* Increased box size */  
            text-align: center;  
            padding: 40px; /* Increased padding */  
            border-radius: 10px;  
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);  
            cursor: pointer;  
            text-decoration: none; /* Remove underline from box links */  
        }  
        .card-container .card .circle {  
            width: 80px; /* Increased circle size */  
            height: 80px; /* Increased circle size */  
            border-radius: 50%;  
            border: 2px solid #007BFF; /* Add border to circle */  
            display: flex;  
            justify-content: center;  
            align-items: center;  
            margin-bottom: 20px; /* Increased margin between emoji and function name */  
            font-size: 40px; /* Increased emoji size */  
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);  
            margin: 0 auto;  
        }  
        .card-container .card .card-body {  
            font-size: 18px;  
            color: #555;  
        }  
        .card-container .card .card-body h5 {  
            font-size: 22px; /* Increased font size for function name */  
            font-weight: normal;  
        }  
        .card-container .card:hover {  
            transform: scale(1.05);  
            transition: transform 0.3s ease;  
        }  
        .card-container .card a {  
            color: inherit;  
            text-decoration: none; /* Ensure text is not underlined in the links */  
        }  
        .welcome-message {  
            text-align: center; /* Centered the welcome message */  
            font-size: 24px;  
            font-weight: bold;  
            margin-top: 30px;  
        }  
    </style>  
</head>  
<body class="bg-light">  

    <!-- Header Section with Logout Button in the top-right corner -->  
    <div class="header">  
        <h1>University of Jaffna</h1>  
        <h2>Scholarship Management System</h2>  
        <!-- Logout button in the top-right corner -->  
        <a href="logout.php" class="logout-btn">➜🚪Logout</a>  
    </div>  

    <!-- Committee Dashboard Section -->
    <div class="container mt-5">
        <div class="box-container"> <!-- Light purple background box for dashboard content -->
            <div class="welcome-message">
                <p>Welcome, <?php echo $_SESSION['name']; ?> 🧑‍💼</p>
            </div>

            <!-- Card Container with Three Boxes (centered) -->
            <div class="card-container">
                <!-- View Profile Box -->
                <a href="committee_profile.php" class="card">
                    <div class="circle">👤</div>
                    <div class="card-body">
                        <h5>View Profile</h5>
                    </div>
                </a>
                <!-- Review Applications Box -->
                <a href="review_applications.php" class="card">
                    <div class="circle">📥</div>
                    <div class="card-body">
                        <h5>Review Applications</h5>
                    </div>
                </a>
                <!-- Disburse Funds Box -->
                <a href="disburse_funds.php" class="card">
                    <div class="circle">💸</div>
                    <div class="card-body">
                        <h5>Disburse Funds</h5>
                    </div>
                </a>
            </div>

            <!-- Card Container with Additional Boxes (for other actions) -->
            <div class="card-container">
                <!-- Payment Records Box -->
                <a href="update_payment.php" class="card">
                    <div class="circle">📝</div>
                    <div class="card-body">
                        <h5>Payment Records</h5>
                    </div>
                </a>
                <!-- Add Scholarship Box -->
                <a href="add_scholarship.php" class="card">
                    <div class="circle">➕</div>
                    <div class="card-body">
                        <h5>Add Scholarship</h5>
                    </div>
                </a>
            </div>
        </div>
    </div>  

</body>  
</html>  
