<?php
session_start();
include('db_config.php');

// Check if the user is logged in
if (isset($_SESSION['user_id'])) {
    $student_id = $_SESSION['user_id'];

    // Fetch existing student profile data
    $query = "SELECT * FROM students WHERE Student_ID='$student_id'";
    $result = $conn->query($query);
    if ($result->num_rows > 0) {
        $student = $result->fetch_assoc();
    } else {
        // Redirect if no student found
        header('Location: student_dashboard.php');
    }

    // Handle the form submission to update GPA and Monthly Income
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $gpa = $_POST['gpa'];
        $income = $_POST['income'];

        // Update query to save changes to GPA and Monthly Income
        $update_query = "UPDATE students SET GPA='$gpa', Parents_Monthly_Income='$income' WHERE Student_ID='$student_id'";

        if ($conn->query($update_query)) {
            echo "Profile updated successfully!";
        } else {
            echo "Error: " . $conn->error;
        }
    }
} else {
    // Redirect to login if the session doesn't exist
    header('Location: index.php');
}
?>

<!-- Form to update GPA and Monthly Income -->
<h3>Edit Profile</h3>
<form method="post">
    <label for="gpa">GPA:</label>
    <input type="text" id="gpa" name="gpa" value="<?php echo $student['GPA']; ?>" required><br><br>
    
    <label for="income">Monthly Income:</label>
    <input type="text" id="income" name="income" value="<?php echo $student['Parents_Monthly_Income']; ?>" required><br><br>
    
    <input type="submit" value="Update Profile">
</form>

<br>
<a href="student_dashboard.php">Back to Dashboard</a>