<?php    
session_start();    
require_once 'db_config.php';    

if (!isset($_SESSION['member_id']) || !isset($_GET['id'])) {    
    header("Location: index.php");    
    exit;    
}    

$app_id = $_GET['id'];
$member_id = $_SESSION['member_id'];
$msg = "";

// Fetch application information
$sql = "SELECT a.*, s.Student_Name, s.GPA, s.Parents_Monthly_Income, sc.Scholarship_Name 
        FROM applications a 
        JOIN students s ON a.Student_ID = s.Student_ID 
        JOIN scholarships sc ON a.Scholarship_ID = sc.Scholarship_ID 
        WHERE a.Application_ID = ? AND a.Status = 'Pending'";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $app_id);
$stmt->execute();
$result = $stmt->get_result();

// Check if the application exists
if ($result->num_rows !== 1) {
    echo "<script>alert('Application not found or already processed.'); window.location.href='review_applications.php';</script>";
    exit;
}

$app = $result->fetch_assoc();

// Method to award points and approve the application
function awardPoints($conn, $app_id, $member_id, $award_id, $points, $comments, $remarks, $award_date) {
    // Begin transaction
    $conn->begin_transaction();
    try {
        // If comments are empty, set a default value (optional)
        if (empty($comments)) {
            $comments = "No comments provided";  // Set default if comments are empty
        }

        // Prepare award insertion query with Award_ID, Remarks, Comments, and Award_Date
        $award_sql = "INSERT INTO scholarship_award (Award_ID, Application_ID, Member_ID, Points, Comments, Remarks, Award_Date) 
                      VALUES (?, ?, ?, ?, ?, ?, ?)";
        $award_stmt = $conn->prepare($award_sql);
        if ($award_stmt === false) {
            throw new Exception("Failed to prepare the award statement: " . $conn->error);
        }

        // Bind parameters and execute
        $award_stmt->bind_param("sssiiss", $award_id, $app_id, $member_id, $points, $comments, $remarks, $award_date);
        $award_stmt->execute();

        // Prepare the update query to change the application status to approved
        $update_sql = "UPDATE applications SET Status = 'Approved' WHERE Application_ID = ?";
        $update_stmt = $conn->prepare($update_sql);
        if ($update_stmt === false) {
            throw new Exception("Failed to prepare the update statement: " . $conn->error);
        }

        // Bind and execute update query
        $update_stmt->bind_param("s", $app_id);
        $update_stmt->execute();

        // Commit the transaction
        $conn->commit();
        return "Application approved and points awarded.";
    } catch (Exception $e) {
        // Rollback in case of error
        $conn->rollback();
        return "Error processing application: " . $e->getMessage();
    }
}

// Handle form submission to award points
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $award_id = $_POST['award_id']; // Get Award_ID from user input
    $points = $_POST['points'];
    $comments = $_POST['comments']; // Get Comments from user input
    $remarks = $_POST['remarks']; // Get Remarks from user input
    $award_date = date('Y-m-d'); // Set Award Date to current date

    // Call function to award points and approve the application
    $msg = awardPoints($conn, $app_id, $member_id, $award_id, $points, $comments, $remarks, $award_date);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Award Points</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container mt-5">
    <div class="card shadow p-4">
        <h3 class="mb-4">🏅 Evaluate & Award Points</h3>
        <?php if ($msg): ?>
            <div class="alert alert-info"><?= $msg ?></div>
        <?php endif; ?>

        <p><strong>Student:</strong> <?= $app['Student_Name'] ?> | <strong>GPA:</strong> <?= $app['GPA'] ?> | <strong>Income:</strong> Rs. <?= number_format($app['Parents_Monthly_Income']) ?></p>
        <p><strong>Scholarship:</strong> <?= $app['Scholarship_Name'] ?> | <strong>Documents:</strong><br> <?= nl2br(htmlspecialchars($app['Documents'])) ?></p>

        <!-- GPA Criteria Table -->
        <h5>GPA Criteria</h5>
        <table class="table table-bordered table-sm">
            <thead>
                <tr>
                    <th>GPA</th>
                    <th>Points</th>
                </tr>
            </thead>
            <tbody>
                <tr><td>>= 3.70</td><td>50</td></tr>
                <tr><td>>= 3.30</td><td>40</td></tr>
                <tr><td>>= 3.00</td><td>30</td></tr>
                <tr><td>>= 2.80</td><td>20</td></tr>
                <tr><td>>= 2.00</td><td>10</td></tr>
                <tr><td>> 2.00</td><td>00</td></tr>
            </tbody>
        </table>

        <!-- Income Criteria Table -->
        <h5>Income Criteria</h5>
        <table class="table table-bordered table-sm">
            <thead>
                <tr>
                    <th>Income Range</th>
                    <th>Points</th>
                </tr>
            </thead>
            <tbody>
                <tr><td>> 50,000</td><td>00</td></tr>
                <tr><td>Between 50,000 and 40,000</td><td>10</td></tr>
                <tr><td>Between 40,000 and 30,000</td><td>20</td></tr>
                <tr><td>Between 30,000 and 20,000</td><td>30</td></tr>
                <tr><td>Between 20,000 and 10,000</td><td>40</td></tr>
                <tr><td><= 10,000</td><td>50</td></tr>
            </tbody>
        </table>

        <form method="POST">
            <div class="mb-3">
                <label>Award ID</label>
                <input type="text" name="award_id" class="form-control" required>
            </div>
            <div class="mb-3">
                <label>Points (0-100)</label>
                <input type="number" name="points" class="form-control" min="0" max="100" required>
            </div>
            <div class="mb-3">
                <label>Comments</label>
                <textarea name="comments" class="form-control" required></textarea>
            </div>
            <div class="mb-3">
                <label>Remarks</label>
                <textarea name="remarks" class="form-control" required></textarea>
            </div>
            <button type="submit" class="btn btn-success">Approve & Submit</button>
            <a href="review_applications.php" class="btn btn-secondary">Back</a>
        </form>
    </div>
</div>
</body>
</html>
