<?php
session_start();
require_once 'db_config.php';

if (!isset($_SESSION['student_id']) || !isset($_GET['id'])) {
    header("Location: index.php");
    exit;
}

$app_id = $_GET['id'];
$student_id = $_SESSION['student_id'];
$msg = "";

// Fetch application to ensure it's the student's and still pending
$sql = "SELECT * FROM applications WHERE Application_ID = ? AND Student_ID = ? AND Status = 'Pending'";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ss", $app_id, $student_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows !== 1) {
    echo "<script>alert('Invalid or locked application.'); window.location.href='view_applications.php';</script>";
    exit;
}

$app = $result->fetch_assoc();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Check if a file is uploaded
    if (isset($_FILES['documents']) && $_FILES['documents']['error'] == 0) {
        // File details
        $file_name = $_FILES['documents']['name'];
        $file_tmp = $_FILES['documents']['tmp_name'];
        $file_size = $_FILES['documents']['size'];
        $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
        
        // Allowed file types
        $allowed_ext = ['pdf', 'jpg', 'jpeg'];
        
        // Check file type
        if (!in_array($file_ext, $allowed_ext)) {
            $msg = "Only PDF or JPG files are allowed.";
        } else {
            // Generate a unique file name
            $new_file_name = uniqid('scholarship_') . '.' . $file_ext;
            $upload_dir = 'uploads/'; // Folder where files will be uploaded
            
            // Create the folder if it doesn't exist
            if (!is_dir($upload_dir)) {
                mkdir($upload_dir, 0777, true);
            }

            $upload_path = $upload_dir . $new_file_name;
            
            // Move the uploaded file to the target directory
            if (move_uploaded_file($file_tmp, $upload_path)) {
                // Update the database with the new file path
                $sql = "UPDATE applications SET Documents = ? WHERE Application_ID = ? AND Student_ID = ?";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("sss", $upload_path, $app_id, $student_id);
                
                if ($stmt->execute()) {
                    $msg = "Application updated successfully with new document.";
                } else {
                    $msg = "Error updating application.";
                }
            } else {
                $msg = "Error uploading the file.";
            }
        }
    } else {
        $msg = "Please choose a file to upload.";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Update Application</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container mt-5">
    <div class="card shadow p-4">
        <h3 class="mb-4">🔁 Update Application</h3>
        <?php if ($msg): ?>
            <div class="alert alert-info"> <?= $msg ?> </div>
        <?php endif; ?>
        <form method="POST" enctype="multipart/form-data">
            <div class="mb-3">
                <label>Documents (PDF/JPG only)</label>
                <input type="file" name="documents" class="form-control" required>
                <small class="text-muted">Only PDF or JPG files are allowed.</small>
            </div>
            <button type="submit" class="btn btn-primary">Update</button>
            <a href="view_applications.php" class="btn btn-secondary">Cancel</a>
        </form>
    </div>
</div>
</body>
</html>
