<?php
session_start();
require_once 'db_config.php';

if (!isset($_SESSION['student_id']) || !isset($_GET['id'])) {
    header("Location: index.php");
    exit;
}

$app_id = $_GET['id'];
$student_id = $_SESSION['student_id'];
$msg = "";

// Fetch application to ensure it's the student's and still pending
$sql = "SELECT * FROM applications WHERE Application_ID = ? AND Student_ID = ? AND Status = 'Pending'";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ss", $app_id, $student_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows !== 1) {
    echo "<script>alert('Invalid or locked application.'); window.location.href='view_applications.php';</script>";
    exit;
}

$app = $result->fetch_assoc();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $documents = $_POST['documents'];
    $sql = "UPDATE applications SET Documents = ? WHERE Application_ID = ? AND Student_ID = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sss", $documents, $app_id, $student_id);
    
    if ($stmt->execute()) {
        $msg = "Application updated successfully.";
    } else {
        $msg = "Error updating application.";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Update Application</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container mt-5">
    <div class="card shadow p-4">
        <h3 class="mb-4">🔁 Update Application</h3>
        <?php if ($msg): ?>
            <div class="alert alert-info"> <?= $msg ?> </div>
        <?php endif; ?>
        <form method="POST">
            <div class="mb-3">
                <label>Documents</label>
                <textarea name="documents" class="form-control" required><?= $app['Documents'] ?></textarea>
            </div>
            <button type="submit" class="btn btn-primary">Update</button>
            <a href="view_applications.php" class="btn btn-secondary">Cancel</a>
        </form>
    </div>
</div>
</body>
</html>