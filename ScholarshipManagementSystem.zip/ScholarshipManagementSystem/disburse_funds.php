<?php    
session_start();    
require_once 'db_config.php';    

if (!isset($_SESSION['member_id'])) {    
    header("Location: index.php");    
    exit;    
}    

$msg = "";    

// Modified SQL query to show scholarship_award details for approved applications (without points, remarks, and comments)
$sql = "SELECT sa.Award_ID, a.Application_ID, s.Student_Name, sc.Scholarship_Name, sa.Award_Date 
        FROM scholarship_award sa    
        JOIN applications a ON sa.Application_ID = a.Application_ID    
        JOIN students s ON a.Student_ID = s.Student_ID    
        JOIN scholarships sc ON a.Scholarship_ID = sc.Scholarship_ID    
        WHERE a.Status = 'Approved'"; // Only fetch approved applications
$result = $conn->query($sql);    

?>

<!DOCTYPE html>    
<html>    
<head>    
    <title>Disburse Funds</title>    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">    
</head>    
<body class="bg-light">    
    <div class="container mt-5">    
        <div class="card shadow p-4">    
            <h3 class="mb-4">💸 Disburse Scholarship Funds</h3>    
            <?php if ($msg): ?>    
                <div class="alert alert-info"> <?= $msg ?> </div>    
            <?php endif; ?>    

            <!-- Message displayed before the table -->
            <div class="alert alert-info">
                <strong>Here are the approved applications. Payment for these applications will be disbursed soon.</strong>
            </div>

            <!-- Table displaying scholarship_award details without Points, Remarks, and Comments -->
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>Award ID</th>
                        <th>Application ID</th>
                        <th>Student Name</th>
                        <th>Scholarship Name</th>
                        <th>Award Date</th>
                    </tr>
                </thead>
                <tbody>
                <?php while ($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?= $row['Award_ID'] ?></td>
                        <td><?= $row['Application_ID'] ?></td>
                        <td><?= $row['Student_Name'] ?></td>
                        <td><?= $row['Scholarship_Name'] ?></td>
                        <td><?= $row['Award_Date'] ?></td>
                    </tr>
                <?php endwhile; ?>
                </tbody>
            </table>

            <!-- Button to go back to the dashboard -->
            <a href="committee_dashboard.php" class="btn btn-secondary mt-3">⬅ Back to Dashboard</a>
        </div>    
    </div>    
</body>    
</html>
