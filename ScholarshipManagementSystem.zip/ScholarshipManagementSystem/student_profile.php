<?php
session_start();

// Connect to the database using db_config
require_once 'db_config.php';

// Check if student is logged in
if (!isset($_SESSION['student_id'])) {
    header("Location: index.php");
    exit;
}

$student_id = $_SESSION['student_id'];

// Prepare and execute the query to fetch student details
$sql = "SELECT * FROM students WHERE Student_ID = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $student_id);
$stmt->execute();
$result = $stmt->get_result();
$student = $result->fetch_assoc();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Student Profile</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
    <div class="container mt-5">
        <div class="card shadow p-4">
            <h3 class="mb-4">👤 Student Profile</h3>
            <table class="table table-bordered">
                <tr>
                    <th>Student ID</th>
                    <td><?php echo htmlspecialchars($student['Student_ID']); ?></td>
                </tr>
                <tr>
                    <th>Name</th>
                    <td><?php echo htmlspecialchars($student['Student_Name']); ?></td>
                </tr>
                <tr>
                    <th>Email</th>
                    <td><?php echo htmlspecialchars($student['Student_Email']); ?></td>
                </tr>
                <tr>
                    <th>GPA</th>
                    <td><?php echo htmlspecialchars($student['GPA']); ?></td>
                </tr>
                <tr>
                    <th>Monthly Income</th>
                    <td>Rs. <?php echo number_format($student['Parents_Monthly_Income'], 2); ?></td>
                </tr>
            </table>
            <a href="student_dashboard.php" class="btn btn-secondary mt-3">⬅ Back to Dashboard</a>
        </div>
    </div>
</body>
</html>