<?php
$host = "localhost";
$user = "root";
$password = ""; // Set your MySQL password here
$database = "scholarship_management_system";

// Create a new MySQLi connection
$conn = new mysqli($host, $user, $password, $database);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>