
<?php
include('db_config.php');

if (isset($_GET['award_id'])) {
    $award_id = $_GET['award_id'];

    $query = "SELECT s.Amount FROM scholarship_award sa 
              JOIN applications a ON sa.Application_ID = a.Application_ID
              JOIN scholarships s ON a.Scholarship_ID = s.Scholarship_ID
              WHERE sa.Award_ID = '$award_id'";

    $result = mysqli_query($conn, $query);
    $row = mysqli_fetch_assoc($result);

    // Return the scholarship amount as JSON
    echo json_encode($row);
}
?>
