<?php
session_start();
require_once 'db_config.php';

if (!isset($_SESSION['student_id'])) {
    header("Location: index.php");
    exit;
}

$student_id = $_SESSION['student_id'];
$sql = "SELECT Student_Name FROM students WHERE Student_ID = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $student_id);
$stmt->execute();
$result = $stmt->get_result();
$student = $result->fetch_assoc();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Student Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
    <div class="container mt-5">
        <div class="card shadow p-4">
            <h2 class="mb-4">Welcome, <?php echo $student['Student_Name']; ?> 🎓</h2>
            <ul class="list-group">
                <li class="list-group-item">
                    <a href="student_profile.php">👤 View Profile</a>
                </li>
                <li class="list-group-item">
                    <a href="apply_scholarship.php">🆕 Apply for Scholarship</a>
                </li>
                <li class="list-group-item">
                    <a href="view_applications.php">📄 View Applications</a>
                </li>
                <li class="list-group-item">
                    <a href="logout.php" class="text-danger">🔓 Logout</a>
                </li>
            </ul>
        </div>
    </div>
</body>
</html>