<?php      
session_start();      
require_once 'db_config.php';      

if (!isset($_SESSION['student_id'])) {      
    header("Location: index.php");      
    exit;      
}      

$student_id = $_SESSION['student_id'];      
$sql = "SELECT Student_Name FROM students WHERE Student_ID = ?";      
$stmt = $conn->prepare($sql);      
$stmt->bind_param("s", $student_id);      
$stmt->execute();      
$result = $stmt->get_result();      
$student = $result->fetch_assoc();      
?>      

<!DOCTYPE html>      
<html>      
<head>      
    <title>Student Dashboard</title>      
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">      
    <style>      
        /* Custom Styling */      
        .header {      
            text-align: center;      
            background-color: #007BFF;      
            color: white;      
            padding: 20px;      
            position: relative;      
        }      
        .header h1 {      
            margin: 0;      
            font-size: 36px;      
        }      
        .header h2 {      
            margin-top: 10px;      
            font-size: 24px;      
        }      
        .header .logout-btn {      
            position: absolute;      
            top: 40px; /* 0.5 cm down */      
            right: 40px;      
            background-color: #66b0ff; /* Light blue color for logout button */      
            color: white;      
            padding: 12px 20px;      
            border-radius: 5px;      
            text-decoration: none; /* Remove underline from the logout button */      
            font-size: 16px; /* Increase the size of the button */      
        }      
        .card-container {      
            display: flex;      
            justify-content: center;      
            gap: 50px; /* Increase the space between boxes */      
            margin-top: 50px; /* Increase space above the boxes */      
        }      
        .card-container .card {      
            width: 280px; /* Increased box size */      
            text-align: center;      
            padding: 40px; /* Increased padding */      
            border-radius: 10px;      
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);      
            cursor: pointer;      
            text-decoration: none; /* Remove underline from box links */      
        }      
        .card-container .card .circle {      
            width: 80px; /* Increased circle size */      
            height: 80px; /* Increased circle size */      
            border-radius: 50%;      
            border: 2px solid #007BFF; /* Add border to circle */      
            display: flex;      
            justify-content: center;      
            align-items: center;      
            margin-bottom: 20px; /* Increased margin between emoji and function name */      
            font-size: 40px; /* Increased emoji size */      
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);      
            margin: 0 auto;      
        }      
        .card-container .card .card-body {      
            font-size: 18px;      
            color: #555;      
        }      
        .card-container .card .card-body h5 {      
            font-size: 22px; /* Increased font size for function name */      
            font-weight: normal;      
        }      
        .card-container .card:hover {      
            transform: scale(1.05);      
            transition: transform 0.3s ease;      
        }      
        .card-container .card a {      
            color: inherit;      
            text-decoration: none; /* Ensure text is not underlined in the links */      
        }      
        .welcome-message {      
            text-align: center; /* Centered the welcome message */      
            font-size: 24px;      
            font-weight: bold;      
            margin-top: 30px;      
        }      
        .box-container {      
            background-color: #E6E6FA; /* Light purple color for the big box */      
            padding: 30px;      
            border-radius: 10px;      
        }      
    </style>      
</head>      
<body class="bg-light">      

    <!-- Header Section with Logout Button in the top-right corner -->      
    <div class="header">      
        <h1>University of Jaffna</h1>      
        <h2>Scholarship Management System</h2>      
        <!-- Logout button in the top-right corner -->      
        <a href="logout.php" class="logout-btn">➜🚪Logout</a>      
    </div>      

    <!-- Student Dashboard Section -->
    <div class="container mt-5">
        <div class="box-container"> <!-- Light purple background box for dashboard content -->
            <div class="welcome-message">
                <p>Welcome, <?php echo $student['Student_Name']; ?> 🎓</p>
            </div>

            <!-- Card Container with Three Boxes (centered) -->
            <div class="card-container">
                <!-- View Profile Box -->
                <a href="student_profile.php" class="card">
                    <div class="circle">👤</div>
                    <div class="card-body">
                        <h5>View Profile</h5>
                    </div>
                </a>
                <!-- Apply for Scholarship Box -->
                <a href="apply_scholarship.php" class="card">
                    <div class="circle">🆕</div>
                    <div class="card-body">
                        <h5>Apply for Scholarship</h5>
                    </div>
                </a>
                <!-- View Applications Box -->
                <a href="view_applications.php" class="card">
                    <div class="circle">📄</div>
                    <div class="card-body">
                        <h5>View Applications</h5>
                    </div>
                </a>
            </div>
        </div>
    </div>  

</body>      
</html>    
