<?php  
session_start();  
require_once 'db_config.php';  

// Check if the user is logged in  
if (!isset($_SESSION['student_id'])) {  
    header("Location: index.php");  
    exit;  
}  

$student_id = $_SESSION['student_id'];  
$msg = "";  

// Fetch scholarships the student has already applied for
$applied_scholarships_sql = "SELECT Scholarship_ID FROM applications WHERE Student_ID = ? AND Status != 'Locked'";
$applied_scholarships_stmt = $conn->prepare($applied_scholarships_sql);
$applied_scholarships_stmt->bind_param("s", $student_id);
$applied_scholarships_stmt->execute();
$applied_scholarships_result = $applied_scholarships_stmt->get_result();
$applied_scholarships = [];
while ($row = $applied_scholarships_result->fetch_assoc()) {
    $applied_scholarships[] = $row['Scholarship_ID'];
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {  
    $scholarship_id = $_POST['scholarship_id'];  
    $documents = ""; // Initialize empty string for documents  

    // Step 1: Check if student has already applied for the selected scholarship (check all statuses, not just pending)  
    if (in_array($scholarship_id, $applied_scholarships)) {
        $msg = "You have already applied for this scholarship or your application is locked.";
    } else {
        // Step 2: Check if the student is eligible for the scholarship based on GPA and parent's monthly income  
        $eligibility_sql = "SELECT Min_GPA, Max_Parents_Monthly_Income FROM scholarships WHERE Scholarship_ID = ?";  
        $eligibility_stmt = $conn->prepare($eligibility_sql);  
        $eligibility_stmt->bind_param("s", $scholarship_id);  
        $eligibility_stmt->execute();  
        $eligibility_result = $eligibility_stmt->get_result();  

        if ($eligibility_result->num_rows > 0) {  
            $scholarship_data = $eligibility_result->fetch_assoc();  
            $min_gpa = $scholarship_data['Min_GPA'];  
            $max_income = $scholarship_data['Max_Parents_Monthly_Income'];  

            // Fetch student's current GPA and parent's monthly income  
            $student_sql = "SELECT GPA, Parents_Monthly_Income FROM students WHERE Student_ID = ?";  
            $student_stmt = $conn->prepare($student_sql);  
            $student_stmt->bind_param("s", $student_id);  
            $student_stmt->execute();  
            $student_result = $student_stmt->get_result();  
            $student_data = $student_result->fetch_assoc();  

            $student_gpa = $student_data['GPA'];  
            $student_income = $student_data['Parents_Monthly_Income'];  

            // Check if student meets eligibility criteria  
            if ($student_gpa >= $min_gpa && $student_income <= $max_income) {  
                // Handle file upload  
                if (isset($_FILES['documents']) && $_FILES['documents']['error'] == 0) {  
                    $allowed_types = ['application/pdf', 'image/jpeg', 'image/png']; // Allowed file types  
                    $file_type = $_FILES['documents']['type'];  

                    if (!in_array($file_type, $allowed_types)) {  
                        $msg = "Invalid file type. Only PDF, JPG, PNG allowed.";  
                    } else {  
                        $upload_dir = 'uploads/'; // Folder where the file will be saved  
                        $file_name = uniqid() . '_' . basename($_FILES['documents']['name']); // Generate unique file name  
                        $upload_path = $upload_dir . $file_name;  

                        // Check if upload directory exists and is writable  
                        if (!is_dir($upload_dir)) {  
                            mkdir($upload_dir, 0777, true); // Create directory if it doesn't exist  
                        }  

                        // Move the uploaded file to the target directory  
                        if (move_uploaded_file($_FILES['documents']['tmp_name'], $upload_path)) {  
                            $documents = $upload_path; // Store the file path in the database  
                        } else {  
                            $msg = "Failed to upload document. Error: " . $_FILES['documents']['error'];  
                        }  
                    }  
                } else {  
                    $msg = "No document selected or file upload error.";  
                }  

                // Step 3: If document is uploaded and eligibility is met, insert the application into the database  
                if ($documents) {  
                    $date_applied = date('Y-m-d');  
                    $sql = "INSERT INTO applications (Student_ID, Scholarship_ID, Date_Applied, Documents, Status) VALUES (?, ?, ?, ?, 'Pending')";  
                    $stmt = $conn->prepare($sql);  
                    $stmt->bind_param("ssss", $student_id, $scholarship_id, $date_applied, $documents);  

                    if ($stmt->execute()) {  
                        $msg = "Application submitted successfully.";  
                    } else {  
                        $msg = "Error submitting application: " . $stmt->error;  
                    }  
                }  
            } else {  
                $msg = "You do not meet the eligibility criteria for this scholarship.";  
            }  
        } else {  
            $msg = "Scholarship not found or invalid criteria.";  
        }  
    }  
}  

// Fetch scholarships available for the student to apply
$eligible_scholarships_sql = "SELECT * FROM scholarships WHERE Scholarship_ID NOT IN (SELECT Scholarship_ID FROM applications WHERE Student_ID = ?) AND Min_GPA <= (SELECT GPA FROM students WHERE Student_ID = ?) AND Max_Parents_Monthly_Income >= (SELECT Parents_Monthly_Income FROM students WHERE Student_ID = ?)";
$eligible_scholarships_stmt = $conn->prepare($eligible_scholarships_sql);
$eligible_scholarships_stmt->bind_param("sss", $student_id, $student_id, $student_id);
$eligible_scholarships_stmt->execute();
$eligible_scholarships_result = $eligible_scholarships_stmt->get_result();

// Fetch all scholarships details (To display below the "Already Applied" section)
$all_scholarships_sql = "SELECT * FROM scholarships";
$all_scholarships_result = $conn->query($all_scholarships_sql);

?>  

<!DOCTYPE html>  
<html>  
<head>  
    <title>Apply for Scholarship</title>  
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">  
</head>  
<body class="bg-light">  
    <div class="container mt-5">  
        <div class="card shadow p-4">  
            <h3 class="mb-4">🆕 Apply for New Scholarship</h3>  
            <?php if ($msg): ?>  
                <div class="alert alert-info"> <?= $msg ?> </div>  
            <?php endif; ?>  
            <h4>Scholarships You Have Already Applied For</h4>  
            <ul>  
                <?php  
                $applied_scholarships_sql = "SELECT Scholarship_Name FROM scholarships WHERE Scholarship_ID IN (SELECT Scholarship_ID FROM applications WHERE Student_ID = ?)";
                $applied_scholarships_stmt = $conn->prepare($applied_scholarships_sql);
                $applied_scholarships_stmt->bind_param("s", $student_id);
                $applied_scholarships_stmt->execute();
                $applied_scholarships_result = $applied_scholarships_stmt->get_result();
                while ($row = $applied_scholarships_result->fetch_assoc()):  
                ?>  
                    <li><?= $row['Scholarship_Name']; ?></li>  
                <?php endwhile; ?>  
            </ul>  

            <!-- Display all scholarships details -->
            <h4>All Available Scholarships</h4>
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>Scholarship Name</th>
                        <th>Amount</th>
                        <th>Min GPA</th>
                        <th>Max Income</th>
                        <th>Deadline</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = $all_scholarships_result->fetch_assoc()): ?>
                        <tr>
                            <td><?= $row['Scholarship_Name'] ?></td>
                            <td>Rs. <?= number_format($row['Amount'], 2) ?></td>
                            <td><?= $row['Min_GPA'] ?></td>
                            <td>Rs. <?= number_format($row['Max_Parents_Monthly_Income'], 2) ?></td>
                            <td><?= $row['Deadline'] ?></td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>

            <h4>Eligible Scholarships You Can Apply For </h4>  
<h6><div class="mb-3">(Eligibility is decided based on the student's GPA and parents' monthly income.
)</div></h6>

            <form method="post" enctype="multipart/form-data">  
                <div class="mb-3">  
                    <label>Scholarship</label>  
                    <select name="scholarship_id" class="form-select" required>  
                        <option value="">-- Select --</option>  
                        <?php while ($row = $eligible_scholarships_result->fetch_assoc()): ?>  
                            <option value="<?php echo $row['Scholarship_ID']; ?>">  
                                <?php echo $row['Scholarship_Name']; ?>  
                            </option>  
                        <?php endwhile; ?>  
                    </select>  
                </div>  
                <div class="mb-3">  
                    <label>Documents (e.g., ID and Transcript)</label>  
                    <input type="file" name="documents" class="form-control" required>  
                </div>  
                <button type="submit" class="btn btn-success">Submit Application</button>  
                <a href="student_dashboard.php" class="btn btn-secondary">Back</a>  
            </form>  
        </div>  
    </div>  
</body>  
</html>  
