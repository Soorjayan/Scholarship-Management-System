 <?php
// Ensure the user is logged in
session_start();
require_once 'db_config.php';

if (!isset($_SESSION['member_id'])) {
    header("Location: index.php");
    exit;
}

// Get the document name from the URL
if (isset($_GET['file'])) {
    $file = $_GET['file'];

    // Define the path to the uploads folder
    $file_path = 'uploads/' . basename($file); // Make sure to sanitize the filename!

    // Check if the file exists
    if (file_exists($file_path)) {
        // Get the file's MIME type
        $mime_type = mime_content_type($file_path);

        // Set appropriate headers
        header('Content-Type: ' . $mime_type);
        header('Content-Disposition: inline; filename="' . basename($file_path) . '"');
        header('Content-Length: ' . filesize($file_path));

        // Read the file and send it to the browser
        readfile($file_path);
        exit;
    } else {
        // If the file doesn't exist, display an error message
        echo "File not found.";
    }
} else {
    echo "No file specified.";
}
?>
