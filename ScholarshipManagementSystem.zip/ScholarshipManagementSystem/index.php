<?php          
session_start();          
require_once 'db_config.php';          
          
$error = "";          
if ($_SERVER['REQUEST_METHOD'] === 'POST') {          
    $email = $_POST['email'];          
    $password = $_POST['password'];          
    $role = $_POST['role'];          
          
    if ($role === 'Student') {          
        $stmt = $conn->prepare("SELECT * FROM students WHERE Student_Email = ?");          
    } else {          
        $stmt = $conn->prepare("SELECT * FROM scholarship_committee WHERE Member_Email = ?");          
    }          
          
    $stmt->bind_param("s", $email);          
    $stmt->execute();          
    $result = $stmt->get_result();          
          
    if ($result && $result->num_rows === 1) {          
        $user = $result->fetch_assoc();          
        $passCheck = ($role === 'Student') ? $user['Password'] : $user['Password'];          
          
        if ($password === $passCheck) {          
            if ($role === 'Student') {          
                $_SESSION['student_id'] = $user['Student_ID'];          
                $_SESSION['name'] = $user['Student_Name'];          
                header("Location: student_dashboard.php");          
                exit;          
            } else {          
                $_SESSION['member_id'] = $user['Member_ID'];          
                $_SESSION['name'] = $user['Member_Name'];          
                $_SESSION['role'] = $user['Member_Role'];          
                header("Location: committee_dashboard.php");          
                exit;          
            }          
        }          
    }          
    $error = "Invalid username or password.";          
}          
?>          
<!DOCTYPE html>          
<html>          
<head>          
    <title>Login</title>          
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">          
    <style>          
        body {          
            background: linear-gradient(to right, #a1c4fd, #c2e9fb);          
            display: flex;          
            justify-content: center;          
            align-items: center;          
            height: 100vh;          
            flex-direction: column;          
        }          
        .login-box {          
            background: white;          
            padding: 30px;          
            border-radius: 10px;          
            width: 100%;          
            max-width: 400px;          
            box-shadow: 0 0 15px rgba(0,0,0,0.1);          
        }          
        .login-box img {          
            width: 70px;          
            display: block;          
            margin: 0 auto 20px;          
        }          
        .header-text {          
            text-align: center;          
            margin-bottom: 20px;          
        }          
    </style>          
</head>          
<body>          
    <div class="header-text">

<h1>University of Jaffna</h1>
<br>

        <h3>Welcome to Scholarship Management System</h3><br>
    </div>
    <div class="login-box">          
        <img src="https://cdn-icons-png.flaticon.com/512/3135/3135715.png" alt="avatar">          
        <h4 class="text-center">Login to Scholarship Portal</h4>          
        <?php if (!empty($error)) echo "<p class='text-danger text-center mt-2'>$error</p>"; ?>          
        <form method="post">          
            <div class="mb-3">          
                <label>Email</label>          
                <input type="email" name="email" class="form-control" required>          
            </div>          
            <div class="mb-3">          
                <label>Password</label>          
                <input type="password" name="password" class="form-control" required>          
            </div>          
            <div class="mb-3">          
                <label>Login As</label>          
                <select name="role" class="form-select" required>          
                    <option value="Student">Student</option>          
                    <option value="Committee">Committee</option>          
                </select>          
            </div>          
            <button type="submit" class="btn btn-primary w-100">Login</button>          
        </form>          
    </div>          
</body>          
</html>
