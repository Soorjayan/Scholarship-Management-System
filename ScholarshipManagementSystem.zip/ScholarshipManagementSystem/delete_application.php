<?php
session_start();
require_once 'db_config.php';

if (!isset($_SESSION['student_id']) || !isset($_GET['id'])) {
    header("Location: index.php");
    exit;
}

$app_id = $_GET['id'];
$student_id = $_SESSION['student_id'];

// Ensure the application belongs to the student and is pending
$sql = "SELECT * FROM applications WHERE Application_ID = ? AND Student_ID = ? AND Status = 'Pending'";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ss", $app_id, $student_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 1) {
    $delete = $conn->prepare("DELETE FROM applications WHERE Application_ID = ? AND Student_ID = ?");
    $delete->bind_param("ss", $app_id, $student_id);
    $delete->execute();
    echo "<script>alert('Application deleted successfully.'); window.location.href='view_applications.php';</script>";
} else {
    echo "<script>alert('Cannot delete approved or invalid application.'); window.location.href='view_applications.php';</script>";
    exit;
}
?>