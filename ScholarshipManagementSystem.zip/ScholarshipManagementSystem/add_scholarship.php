<?php  
session_start();  
require_once 'db_config.php'; // ✅ Connect to the database if needed  

// Check if the user is logged in  
if (!isset($_SESSION['member_id'])) {  
    header("Location: index.php");  
    exit;  
}  

$msg = "";  

// Handle adding a new scholarship
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_scholarship'])) {
    $scholarship_name = $_POST['scholarship_name'];
    $amount = $_POST['amount'];
    $min_gpa = $_POST['min_gpa'];
    $max_income = $_POST['max_income'];
    $deadline = $_POST['deadline'];

    if (empty($scholarship_name) || empty($amount) || empty($min_gpa) || empty($max_income) || empty($deadline)) {
        $msg = "All fields are required!";
    } else {
        // Insert the new scholarship into the scholarships table
        $sql = "INSERT INTO scholarships (Scholarship_Name, Amount, Min_GPA, Max_Parents_Monthly_Income, Deadline) 
                VALUES (?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sdiis", $scholarship_name, $amount, $min_gpa, $max_income, $deadline);

        if ($stmt->execute()) {
            $msg = "Scholarship added successfully.";
        } else {
            $msg = "Error adding scholarship: " . $stmt->error;
        }
    }
}

// Handle editing an existing scholarship
if (isset($_GET['edit_id'])) {
    $scholarship_id = $_GET['edit_id'];

    // Fetch scholarship details
    $sql = "SELECT * FROM scholarships WHERE Scholarship_ID = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $scholarship_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $scholarship = $result->fetch_assoc();

    if (!$scholarship) {
        $msg = "Scholarship not found!";
    }
}

// Handle updating the scholarship details
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_scholarship'])) {
    $scholarship_id = $_POST['scholarship_id'];
    $scholarship_name = $_POST['scholarship_name'];
    $amount = $_POST['amount'];
    $min_gpa = $_POST['min_gpa'];
    $max_income = $_POST['max_income'];
    $deadline = $_POST['deadline'];

    if (empty($scholarship_name) || empty($amount) || empty($min_gpa) || empty($max_income) || empty($deadline)) {
        $msg = "All fields are required!";
    } else {
        // Update the scholarship
        $sql = "UPDATE scholarships SET Scholarship_Name = ?, Amount = ?, Min_GPA = ?, Max_Parents_Monthly_Income = ?, Deadline = ? 
                WHERE Scholarship_ID = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sdiiss", $scholarship_name, $amount, $min_gpa, $max_income, $deadline, $scholarship_id);

        if ($stmt->execute()) {
            $msg = "Scholarship updated successfully.";
        } else {
            $msg = "Error updating scholarship: " . $stmt->error;
        }
    }
}

// Handle deleting a scholarship
if (isset($_GET['delete_id'])) {
    $delete_scholarship_id = $_GET['delete_id'];

    // Delete the scholarship from the database
    $sql = "DELETE FROM scholarships WHERE Scholarship_ID = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $delete_scholarship_id);

    if ($stmt->execute()) {
        $msg = "Scholarship deleted successfully.";
    } else {
        $msg = "Error deleting scholarship: " . $stmt->error;
    }
}

// Fetch all scholarships
$sql = "SELECT * FROM scholarships";
$result = $conn->query($sql);

?>

<!DOCTYPE html>
<html>
<head>
    <title>Add or Edit Scholarship</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script>
        // Toggle the visibility of Add and Edit forms
        function toggleForm(formType) {
            if (formType === 'add') {
                document.getElementById('addScholarshipForm').style.display = 'block';
                document.getElementById('editScholarshipForm').style.display = 'none';
            } else {
                document.getElementById('editScholarshipForm').style.display = 'block';
                document.getElementById('addScholarshipForm').style.display = 'none';
            }
        }
    </script>
</head>
<body class="bg-light">
    <div class="container mt-5">
        <div class="card shadow p-4">
            <h3 class="mb-4">➕ Add or Edit Scholarship</h3>

            <?php if ($msg): ?>
                <div class="alert alert-info"><?= $msg ?></div>
            <?php endif; ?>

            <!-- Display Existing Scholarships -->
            <h4>Existing Scholarships</h4>
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>Scholarship Name</th>
                        <th>Amount</th>
                        <th>Min GPA</th>
                        <th>Max Income</th>
                        <th>Deadline</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = $result->fetch_assoc()): ?>
                        <tr>
                            <td><?= $row['Scholarship_Name'] ?></td>
                            <td>Rs. <?= number_format($row['Amount'], 2) ?></td>
                            <td><?= $row['Min_GPA'] ?></td>
                            <td>Rs. <?= number_format($row['Max_Parents_Monthly_Income'], 2) ?></td>
                            <td><?= $row['Deadline'] ?></td>
                            <td>
                                <a href="add_scholarship.php?edit_id=<?= $row['Scholarship_ID'] ?>" class="btn btn-warning btn-sm">Edit</a>
                                <a href="add_scholarship.php?delete_id=<?= $row['Scholarship_ID'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this scholarship?')">Delete</a>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>

            <!-- Button to Add Scholarship -->
            <button class="btn btn-success mb-3" onclick="toggleForm('add')">Add New Scholarship</button>

            <!-- Add Scholarship Form -->
            <div id="addScholarshipForm" style="display:none;">
                <h4>Add New Scholarship</h4>
                <form method="POST" action="add_scholarship.php">
                    <div class="mb-3">
                        <label>Scholarship Name</label>
                        <input type="text" name="scholarship_name" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label>Amount</label>
                        <input type="number" name="amount" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label>Min GPA</label>
                        <input type="number" name="min_gpa" class="form-control" step="0.01" required>
                    </div>
                    <div class="mb-3">
                        <label>Max Parents Monthly Income</label>
                        <input type="number" name="max_income" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label>Deadline</label>
                        <input type="date" name="deadline" class="form-control" required>
                    </div>
                    <button type="submit" name="add_scholarship" class="btn btn-success">Add Scholarship</button>
                </form>
            </div>

            <!-- Edit Scholarship Form -->
            <?php if (isset($_GET['edit_id'])): ?>
                <div id="editScholarshipForm">
                    <h4>Edit Scholarship</h4>
                    <form method="POST" action="add_scholarship.php">
                        <input type="hidden" name="scholarship_id" value="<?= $scholarship['Scholarship_ID'] ?>">
                        <div class="mb-3">
                            <label>Scholarship Name</label>
                            <input type="text" name="scholarship_name" class="form-control" value="<?= $scholarship['Scholarship_Name'] ?>" required>
                        </div>
                        <div class="mb-3">
                            <label>Amount</label>
                            <input type="number" name="amount" class="form-control" value="<?= $scholarship['Amount'] ?>" required>
                        </div>
                        <div class="mb-3">
                            <label>Min GPA</label>
                            <input type="number" name="min_gpa" class="form-control" value="<?= $scholarship['Min_GPA'] ?>" step="0.01" required>
                        </div>
                        <div class="mb-3">
                            <label>Max Parents Monthly Income</label>
                            <input type="number" name="max_income" class="form-control" value="<?= $scholarship['Max_Parents_Monthly_Income'] ?>" required>
                        </div>
                        <div class="mb-3">
                            <label>Deadline</label>
                            <input type="date" name="deadline" class="form-control" value="<?= $scholarship['Deadline'] ?>" required>
                        </div>
                        <button type="submit" name="update_scholarship" class="btn btn-primary">Update Scholarship</button>
                    </form>
                </div>
            <?php endif; ?>

            <a href="committee_dashboard.php" class="btn btn-secondary mt-3">⬅ Back to Dashboard</a>
        </div>
    </div>
</body>
</html>
