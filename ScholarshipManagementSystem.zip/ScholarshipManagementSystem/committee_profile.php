<?php
session_start();
require_once 'db_config.php';

if (!isset($_SESSION['member_id'])) {
    header("Location: index.php");
    exit;
}

$member_id = $_SESSION['member_id'];
$sql = "SELECT * FROM scholarship_committee WHERE Member_ID = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $member_id);
$stmt->execute();
$result = $stmt->get_result();
$member = $result->fetch_assoc();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Committee Profile</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
    <div class="container mt-5">
        <div class="card shadow p-4">
            <h3 class="mb-4">👤 Committee Member Profile</h3>
            <table class="table table-bordered">
                <tr>
                    <th>Member ID</th>
                    <td><?php echo $member['Member_ID']; ?></td>
                </tr>
                <tr>
                    <th>Name</th>
                    <td><?php echo $member['Member_Name']; ?></td>
                </tr>
                <tr>
                    <th>Email</th>
                    <td><?php echo $member['Member_Email']; ?></td>
                </tr>
                <tr>
                    <th>Role</th>
                    <td><?php echo $member['Member_Role']; ?></td>
                </tr>
            </table>
            <a href="committee_dashboard.php" class="btn btn-secondary mt-3">⬅ Back to Dashboard</a>
        </div>
    </div>
</body>
</html>