<?php    
session_start();    
require_once 'db_config.php';    

// Ensure the user is logged in
if (!isset($_SESSION['member_id'])) {    
    header("Location: index.php");    
    exit;    
}    

// Fetch the payment records
$sql = "SELECT Payment_ID, Award_ID, Paid_Amount, Date_Paid, Transaction_Reference
        FROM payment";

$result = $conn->query($sql);    
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment Records</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container mt-5">
    <div class="card shadow p-4">
        <h3 class="mb-4">💰 Payment Records</h3>
        
        <!-- Check if there are any records to display -->
        <?php if ($result->num_rows > 0): ?>
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>Payment ID</th>
                        <th>Award ID</th>
                        <th>Amount Paid</th>
                        <th>Date Paid</th>
                        <th>Transaction Reference</th>
                    </tr>
                </thead>
                <tbody>
                <?php while ($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?= $row['Payment_ID'] ?></td>
                        <td><?= $row['Award_ID'] ?></td>
                        <td>Rs. <?= number_format($row['Paid_Amount'], 2) ?></td>
                        <td><?= $row['Date_Paid'] ?></td>
                        <td><?= $row['Transaction_Reference'] ?></td>
                    </tr>
                <?php endwhile; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p>No payment records found.</p>
        <?php endif; ?>

        <!-- Back to Dashboard Button -->
        <a href="committee_dashboard.php" class="btn btn-secondary">⬅ Back to Dashboard</a>
    </div>
</div>
</body>
</html>
