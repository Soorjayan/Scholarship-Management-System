-- Database: `scholarship_management_system`
--

-- --------------------------------------------------------

--
-- Table structure for table `applications`
--

CREATE TABLE `applications` (
  `Application_ID` int(11) NOT NULL,
  `Student_ID` varchar(10) DEFAULT NULL,
  `Scholarship_ID` varchar(10) DEFAULT NULL,
  `Date_Applied` date DEFAULT NULL,
  `Documents` text DEFAULT NULL,
  `Status` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `applications`
--

INSERT INTO `applications` (`Application_ID`, `Student_ID`, `Scholarship_ID`, `Date_Applied`, `Documents`, `Status`) VALUES
(1, 'S001', 'SCH001', '2025-06-01', 'ID and Transcript', 'Approved'),
(2, 'S002', 'SCH002', '2025-06-02', 'ID and Transcripts', 'Pending'),
(3, 'S003', 'SCH003', '2025-06-03', 'ID and Transcript', 'Pending'),
(4, 'S004', 'SCH004', '2025-06-04', 'ID and Transcript', 'Pending'),
(5, 'S005', 'SCH005', '2025-06-05', 'ID and Transcript', 'Pending');

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE `payment` (
  `Payment_ID` varchar(10) NOT NULL,
  `Award_ID` varchar(10) DEFAULT NULL,
  `Paid_Amount` decimal(10,2) DEFAULT NULL,
  `Date_Paid` date DEFAULT NULL,
  `Transaction_Reference` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `payment`
--

INSERT INTO `payment` (`Payment_ID`, `Award_ID`, `Paid_Amount`, `Date_Paid`, `Transaction_Reference`) VALUES
('P001', 'A001', 10000.00, '2025-06-20', 'TXN001'),
('P002', 'A002', 8000.00, '2025-06-21', 'TXN002'),
('P003', 'A003', 6000.00, '2025-06-22', 'TXN003'),
('P004', 'A004', 4000.00, '2025-06-23', 'TXN004'),
('P005', 'A005', 2000.00, '2025-06-24', 'TXN005');

-- --------------------------------------------------------

--
-- Table structure for table `scholarships`
--

CREATE TABLE `scholarships` (
  `Scholarship_ID` varchar(10) NOT NULL,
  `Scholarship_Name` varchar(100) DEFAULT NULL,
  `Amount` decimal(10,2) DEFAULT NULL,
  `Min_GPA` decimal(3,2) DEFAULT NULL,
  `Max_Parents_Monthly_Income` decimal(10,2) DEFAULT NULL,
  `Deadline` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `scholarships`
--

INSERT INTO `scholarships` (`Scholarship_ID`, `Scholarship_Name`, `Amount`, `Min_GPA`, `Max_Parents_Monthly_Income`, `Deadline`) VALUES
('SCH001', 'Mahapola', 10000.00, 3.70, 50000.00, '2025-09-01'),
('SCH002', 'Bursery', 8000.00, 3.30, 40000.00, '2025-09-02'),
('SCH003', 'IMF', 6000.00, 3.00, 30000.00, '2025-09-03'),
('SCH004', 'SLBLA', 4000.00, 2.80, 20000.00, '2025-09-04'),
('SCH005', 'LTDF', 2000.00, 2.00, 18000.00, '2025-09-05');

-- --------------------------------------------------------

--
-- Table structure for table `scholarship_award`
--

CREATE TABLE `scholarship_award` (
  `Award_ID` varchar(10) NOT NULL,
  `Application_ID` int(11) DEFAULT NULL,
  `Member_ID` varchar(10) DEFAULT NULL,
  `Award_Date` date DEFAULT NULL,
  `Points` int(11) DEFAULT NULL,
  `Remarks` text DEFAULT NULL,
  `Comments` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `scholarship_award`
--

INSERT INTO `scholarship_award` (`Award_ID`, `Application_ID`, `Member_ID`, `Award_Date`, `Points`, `Remarks`, `Comments`) VALUES
('A001', 1, 'M001', '2025-06-10', 90, 'High GPA and low income', NULL),
('A002', 2, 'M002', '2025-06-11', 80, 'Eligible under income criteria', NULL),
('A003', 3, 'M003', '2025-06-12', 70, 'Meets basic requirements', NULL),
('A004', 4, 'M004', '2025-06-13', 60, 'Barely eligible', NULL),
('A005', 5, 'M005', '2025-06-14', 85, 'Strong financial need', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `scholarship_committee`
--

CREATE TABLE `scholarship_committee` (
  `Member_ID` varchar(10) NOT NULL,
  `Member_Name` varchar(100) DEFAULT NULL,
  `Member_Email` varchar(100) DEFAULT NULL,
  `Member_Role` varchar(50) DEFAULT NULL,
  `Username` varchar(100) DEFAULT NULL,
  `Password` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `scholarship_committee`
--

INSERT INTO `scholarship_committee` (`Member_ID`, `Member_Name`, `Member_Email`, `Member_Role`, `Username`, `Password`) VALUES
('M001', 'Mitchell Starc', 'starc@jfn.ac.lk', 'Chairperson', 'starc@jfn.ac.lk', 'starc123'),
('M002', 'Josh Hazlewood', 'hazelwood@jfn.ac.lk', 'Reviewer', 'hazelwood@jfn.ac.lk', 'hazelwood123'),
('M003', 'Adam Zampa', 'zampa@jfn.ac.lk', 'Reviewer', 'zampa@jfn.ac.lk', 'zampa123'),
('M004', 'Pat Cummins', 'cummins@jfn.ac.lk', 'Advisor', 'cummins@jfn.ac.lk', 'cummins123'),
('M005', 'Mitchell Johnson', 'johnson@jfn.ac.lk', 'External Reviewer', 'johnson@jfn.ac.lk', 'johnson123');

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `Student_ID` varchar(10) NOT NULL,
  `Student_Name` varchar(100) DEFAULT NULL,
  `Student_Email` varchar(100) DEFAULT NULL,
  `GPA` decimal(3,2) DEFAULT NULL,
  `Parents_Monthly_Income` decimal(10,2) DEFAULT NULL,
  `Username` varchar(100) DEFAULT NULL,
  `Password` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`Student_ID`, `Student_Name`, `Student_Email`, `GPA`, `Parents_Monthly_Income`, `Username`, `Password`) VALUES
('S001', 'Ben Stokes', 'ben@jfn.ac.lk', 3.85, 16000.00, 'ben@jfn.ac.lk', 'ben123'),
('S002', 'Jos Butler', 'jos@jfn.ac.lk', 3.60, 36000.00, 'jos@jfn.ac.lk', 'jos123'),
('S003', 'Jofra Archer', 'archer@jfn.ac.lk', 3.27, 24000.00, 'archer@jfn.ac.lk', 'archer123'),
('S004', 'Joe Root', 'joe@jfn.ac.lk', 2.87, 20000.00, 'joe@jfn.ac.lk', 'joe123'),
('S005', 'Sam Curran', 'sam@jfn.ac.lk', 2.40, 16000.00, 'sam@jfn.ac.lk', 'sam123');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `applications`
--
ALTER TABLE `applications`
  ADD PRIMARY KEY (`Application_ID`),
  ADD KEY `Student_ID` (`Student_ID`),
  ADD KEY `Scholarship_ID` (`Scholarship_ID`);

--
-- Indexes for table `payment`
--
ALTER TABLE `payment`
  ADD PRIMARY KEY (`Payment_ID`),
  ADD KEY `Award_ID` (`Award_ID`);

--
-- Indexes for table `scholarships`
--
ALTER TABLE `scholarships`
  ADD PRIMARY KEY (`Scholarship_ID`);

--
-- Indexes for table `scholarship_award`
--
ALTER TABLE `scholarship_award`
  ADD PRIMARY KEY (`Award_ID`),
  ADD KEY `Member_ID` (`Member_ID`),
  ADD KEY `fk_application_id` (`Application_ID`);

--
-- Indexes for table `scholarship_committee`
--
ALTER TABLE `scholarship_committee`
  ADD PRIMARY KEY (`Member_ID`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`Student_ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `applications`
--
ALTER TABLE `applications`
  MODIFY `Application_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `applications`
--
ALTER TABLE `applications`
  ADD CONSTRAINT `applications_ibfk_1` FOREIGN KEY (`Student_ID`) REFERENCES `students` (`Student_ID`),
  ADD CONSTRAINT `applications_ibfk_2` FOREIGN KEY (`Scholarship_ID`) REFERENCES `scholarships` (`Scholarship_ID`);

--
-- Constraints for table `payment`
--
ALTER TABLE `payment`
  ADD CONSTRAINT `payment_ibfk_1` FOREIGN KEY (`Award_ID`) REFERENCES `scholarship_award` (`Award_ID`);

--
-- Constraints for table `scholarship_award`
--
ALTER TABLE `scholarship_award`
  ADD CONSTRAINT `fk_application_id` FOREIGN KEY (`Application_ID`) REFERENCES `applications` (`Application_ID`) ON DELETE CASCADE,
  ADD CONSTRAINT `scholarship_award_ibfk_2` FOREIGN KEY (`Member_ID`) REFERENCES `scholarship_committee` (`Member_ID`);
COMMIT;

